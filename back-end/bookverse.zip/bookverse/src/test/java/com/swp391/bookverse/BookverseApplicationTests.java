package com.swp391.bookverse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookverseApplicationTests {

	@Test
	void contextLoads() {
	}

}
