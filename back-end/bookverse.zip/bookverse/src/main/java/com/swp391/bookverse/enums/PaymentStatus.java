package com.swp391.bookverse.enums;

/**
 * @Author huangdat
 */
public enum PaymentStatus {
    PENDING, SUCCESS, FAILED
}
