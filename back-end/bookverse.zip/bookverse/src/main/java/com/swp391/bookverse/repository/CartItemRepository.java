package com.swp391.bookverse.repository;

public interface CartItemRepository {
}
