package com.swp391.bookverse.enums;

/**
 * @Author huangdat
 */
public enum PaymentMethod {
    COD,
    VNPAY,
}
