package com.swp391.bookverse.enums;

/**
 * @Author huangdat
 */

public enum Role {
    ADMIN,
    STAFF,
    CUSTOMER,
    ;
}
