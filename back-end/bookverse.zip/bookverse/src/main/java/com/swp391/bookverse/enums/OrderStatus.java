package com.swp391.bookverse.enums;

public enum OrderStatus {
    PENDING,
    PROCESSING,
    DELIVERED,
    CANCELED,
    RETURNED,
}
