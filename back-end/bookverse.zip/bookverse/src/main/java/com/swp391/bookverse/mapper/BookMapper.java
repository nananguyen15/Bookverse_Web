package com.swp391.bookverse.mapper;

import org.mapstruct.Mapper;

/**
 * @Author huangdat
 */
@Mapper(componentModel = "spring")
public interface BookMapper {

}
